"""Optional CPU evaluation. ArcFace/alignment copied from original notebook, no generation."""

import os, json, zipfile, shutil, urllib.request

from pathlib import Path

from types import SimpleNamespace

import numpy as np

import cv2

from PIL import Image

ARCFACE_ZIP_URL = "https://github.com/deepinsight/insightface/releases/download/v0.7/buffalo_l.zip"

def download(url: str, path: str) -> str:
    if os.path.exists(path) and os.path.getsize(path) > 0:
        return path
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".part"
    urllib.request.urlretrieve(url, tmp)
    os.replace(tmp, path)
    return path

def eye_centers(pts: np.ndarray):
    """(image-left eye centre, image-right eye centre)."""
    a = pts[[33, 133]].mean(0)
    b = pts[[362, 263]].mean(0)
    return (a, b) if a[0] <= b[0] else (b, a)

def similarity_transform(src, dst) -> np.ndarray:
    """Least-squares similarity (Umeyama, no reflection). Returns a 2x3 matrix mapping src->dst."""
    src = np.asarray(src, np.float64)
    dst = np.asarray(dst, np.float64)
    mu_s, mu_d = src.mean(0), dst.mean(0)
    s0, d0 = src - mu_s, dst - mu_d
    cov = d0.T @ s0 / len(src)
    U, S, Vt = np.linalg.svd(cov)
    D = np.eye(2)
    if np.linalg.det(U) * np.linalg.det(Vt) < 0:
        D[1, 1] = -1
    R = U @ D @ Vt
    var_s = (s0 ** 2).sum() / len(src)
    scale = float(np.trace(np.diag(S) @ D) / var_s)
    t = mu_d - scale * R @ mu_s
    return np.hstack([scale * R, t[:, None]]).astype(np.float32)

fc = SimpleNamespace(download=download, eye_centers=eye_centers, similarity_transform=similarity_transform, NOSE_TIP=1, MOUTH_CORNERS=(61,291))

class ArcFace:
    """insightface buffalo_l recognition model (w600k_r50) run with onnxruntime; MediaPipe landmarks for alignment."""

    TEMPLATE = np.array([[38.2946, 51.6963], [73.5318, 51.5014], [56.0252, 71.7366],
                         [41.5493, 92.3655], [70.7299, 92.2041]], np.float32)

    def __init__(self, model_dir="models", zip_url=ARCFACE_ZIP_URL, member="w600k_r50.onnx"):
        import onnxruntime as ort
        path = os.path.join(model_dir, member)
        if not os.path.exists(path):
            zpath = fc.download(zip_url, os.path.join(model_dir, "buffalo_l.zip"))
            with zipfile.ZipFile(zpath) as zf:
                name = next(n for n in zf.namelist() if n.endswith(member))
                with zf.open(name) as src, open(path + ".part", "wb") as dst:
                    shutil.copyfileobj(src, dst)
            os.replace(path + ".part", path)
        self.sess = ort.InferenceSession(path, providers=["CPUExecutionProvider"])
        self.inp = self.sess.get_inputs()[0].name

    @staticmethod
    def five_points(pts: np.ndarray) -> np.ndarray:
        le, re_ = fc.eye_centers(pts)
        a, b = pts[fc.MOUTH_CORNERS[0]], pts[fc.MOUTH_CORNERS[1]]
        ml, mr = (a, b) if a[0] <= b[0] else (b, a)
        return np.stack([le, re_, pts[fc.NOSE_TIP], ml, mr]).astype(np.float32)

    def align(self, rgb: np.ndarray, pts: np.ndarray, size: int = 112) -> np.ndarray:
        """Same geometry as insightface face_align.norm_crop (112 -> template, 224 -> template x 2)."""
        M = fc.similarity_transform(self.five_points(pts), self.TEMPLATE * (size / 112.0))
        return cv2.warpAffine(rgb, M, (size, size), flags=cv2.INTER_LINEAR, borderValue=0)

    def embed(self, rgb: np.ndarray, pts: np.ndarray) -> np.ndarray:
        crop = self.align(rgb, pts, 112).astype(np.float32)
        x = ((crop - 127.5) / 127.5).transpose(2, 0, 1)[None]          # RGB, as insightface feeds it
        e = self.sess.run(None, {self.inp: x})[0][0].astype(np.float32)
        return e / (np.linalg.norm(e) + 1e-8)


def evaluate(root):
    import mediapipe as mp
    from mediapipe.tasks.python import BaseOptions, vision
    root = Path(root)
    cfg = json.loads((root / 'config.json').read_text(encoding='utf-8'))
    model_dir = Path(cfg['asset_dir']) / 'identity'
    model_dir.mkdir(parents=True, exist_ok=True)
    path = download('https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task',
                    str(model_dir / 'face_landmarker.task'))
    landmarker = vision.FaceLandmarker.create_from_options(
        vision.FaceLandmarkerOptions(base_options=BaseOptions(model_asset_path=path), num_faces=4))
    arcface = ArcFace(str(model_dir))

    def embedding(image_path):
        with Image.open(image_path) as im:
            rgb = np.asarray(im.convert('RGB'))
        h, w = rgb.shape[:2]
        found = landmarker.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=np.ascontiguousarray(rgb)))
        points = [np.array([[p.x*w, p.y*h] for p in lm], dtype=np.float32) for lm in found.face_landmarks]
        points.sort(key=lambda pts: np.linalg.norm(eye_centers(pts)[1]-eye_centers(pts)[0]), reverse=True)
        return (arcface.embed(rgb, points[0]) if points else None), len(points)

    ref_cache, scores = {}, {}
    case_lookup = {c['case_id']: c for c in cfg['cases']}
    for mode in cfg['precisions']:
        results = root / mode / 'results.json'
        if not results.is_file():
            continue
        for row in json.loads(results.read_text(encoding='utf-8')):
            if row['status'] != 'ok':
                continue
            try:
                refpath = case_lookup[row['case_id']]['photo_path']
                if refpath not in ref_cache:
                    ref_cache[refpath] = embedding(refpath)
                ref, ref_n = ref_cache[refpath]
                emb, n = embedding(root / row['image'])
                state = 'ok' if ref is not None and emb is not None else 'face_not_found'
                scores[row['image']] = dict(identity_status=state, n_faces=n, reference_n_faces=ref_n,
                                            id_sim=float(np.dot(ref, emb)) if state == 'ok' else None)
            except Exception as exc:
                scores[row['image']] = dict(identity_status='error', identity_error=repr(exc), id_sim=None)
    landmarker.close()
    (root / 'identity.json').write_text(json.dumps(scores, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'Identity evaluation: {len(scores)} outputs; using original w600k_r50 and alignment.')


if __name__ == '__main__':
    import sys
    evaluate(sys.argv[1])
