"""Reference preprocessing and literal prompt manifest. No prompt rewriting."""

import numpy as np

from PIL import Image, ImageOps

def load_rgb(src, max_side: int = 1600) -> np.ndarray:
    """Load an image (path or PIL), apply EXIF rotation, return HxWx3 uint8 RGB."""
    im = src if isinstance(src, Image.Image) else Image.open(src)
    im = ImageOps.exif_transpose(im).convert("RGB")
    if max(im.size) > max_side:
        s = max_side / max(im.size)
        im = im.resize((round(im.width * s), round(im.height * s)), Image.LANCZOS)
    return np.array(im)

def fit_max_side(rgb: np.ndarray, max_side: int) -> np.ndarray:
    h, w = rgb.shape[:2]
    s = max_side / max(h, w)
    if s >= 1:
        return rgb
    import cv2
    return cv2.resize(rgb, (round(w * s), round(h * s)), interpolation=cv2.INTER_AREA)



def make_cases(image_paths, input_dir, prompts, seed, reference_max_side):
    from pathlib import Path
    import hashlib
    if not prompts or any(not isinstance(p, str) or not p.strip() for p in prompts):
        raise ValueError('At least one nonempty literal prompt is required.')
    input_dir = Path(input_dir)
    input_dir.mkdir(parents=True, exist_ok=True)
    cases = []
    for fi, path in enumerate(image_paths):
        path = Path(path)
        photo = load_rgb(path, max_side=1600)
        ref = Image.fromarray(fit_max_side(photo, reference_max_side))
        fid = f'image{fi:02d}'
        photo_path = input_dir / f'{fid}_photo.png'
        ref_path = input_dir / f'{fid}_reference.png'
        Image.fromarray(photo).save(photo_path)
        ref.save(ref_path)
        digest = hashlib.sha256(ref_path.read_bytes()).hexdigest()
        for ii, prompt in enumerate(prompts):
            cases.append(dict(case_id=f'{fid}_p{ii:02d}_custom', face=path.name,
                              instruction=prompt, prompt=prompt, lang='custom',
                              prompt_label=f'Prompt {ii+1}', seed=seed,
                              photo_path=str(photo_path), reference_path=str(ref_path),
                              reference_sha256=digest, reference_size=list(ref.size)))
    return cases
