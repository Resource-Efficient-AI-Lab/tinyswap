"""One CUDA process per precision. Only S2c; no SD1.5, masks, warps or face swapping."""
import argparse
import gc
import hashlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import platform
import sys
import time
import traceback

import numpy as np
from PIL import Image


def write_json(path, obj):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    tmp.replace(path)


def storage_bytes(model):
    """Count actual unique tensor storage, including packed weights and quantization metadata.

    Quanto state_dict serialization normally exposes plain tensors. Recurse through tensor
    subclasses as well; never estimate a packed tensor as numel * its apparent BF16 dtype.
    """
    import torch
    seen, total = set(), 0

    def visit(t):
        nonlocal total
        if not isinstance(t, torch.Tensor):
            return
        if type(t) not in (torch.Tensor, torch.nn.Parameter) and hasattr(t, '__tensor_flatten__'):
            names, _ = t.__tensor_flatten__()
            for name in names:
                visit(getattr(t, name))
            return
        s = t.untyped_storage()
        key = (str(t.device), s.data_ptr(), s.nbytes())
        if key not in seen:
            seen.add(key)
            total += s.nbytes()

    for t in model.state_dict().values():
        visit(t)
    return total


def quantize_component(model, precision, exclude, component_name, int4_backend='quanto_tinygemm'):
    if precision == 'int4' and int4_backend == 'dequant_bf16':
        # Same Quanto qint4 numerics; 4-bit packed storage + BF16 dequant + cuBLAS (klein_w4a16.py).
        from klein_w4a16 import quantize_module_w4a16
        return quantize_module_w4a16(model, exclude, component_name)
    import fnmatch
    import torch
    from optimum.quanto import freeze, qint4, qint8, quantization_map, quantize

    # Explicit allowlist: Linear weights only; embeddings, normalization and convolutions stay BF16.
    targets = [name for name, m in model.named_modules()
               if isinstance(m, torch.nn.Linear)
               and not any(fnmatch.fnmatchcase(name, p) for p in exclude)]
    if not targets:
        raise RuntimeError(f'{component_name}: no Linear layers selected; refusing an unquantized result.')
    original_elements = {name: m.weight.numel() for name, m in model.named_modules() if name in targets}
    qtype = qint8 if precision == 'int8' else qint4
    quantize(model, weights=qtype, activations=None, include=targets)
    freeze(model)  # Essential: replace float weights with packed integer weights, not fake quantization.
    actual = quantization_map(model)
    if set(actual) != set(targets):
        raise RuntimeError(f'{component_name}: requested {len(targets)} layers, quantized {len(actual)}.')
    for name, settings in actual.items():
        if settings['weights'] != qtype.name or settings['activations'] != 'none':
            raise RuntimeError(f'Unexpected quantization at {component_name}.{name}: {settings}')
        w = model.get_submodule(name).weight
        if getattr(w, 'qtype', None) != qtype:
            raise RuntimeError(f'{component_name}.{name}: weight was not frozen to {precision}.')
    return dict(component=component_name, quantized_linear_layers=len(actual),
                quantized_weight_elements=sum(original_elements.values()),
                excluded_patterns=exclude, quantization_map=actual)


def kernel_label(precision, int4_backend):
    if precision == 'bf16':
        return 'BF16 weights + cuBLAS'
    if precision == 'int8':
        return 'Quanto qint8 -> BF16 dequant + cuBLAS'
    if int4_backend == 'dequant_bf16':
        return 'qint4 packed -> BF16 dequant + cuBLAS'
    return 'Quanto qint4 -> tinygemm (torch._weight_int4pack_mm)'


def quantization_smoke_test(precision, int4_backend='quanto_tinygemm'):
    """Fail quickly on incompatible Torch/Quanto/CUDA installations, before loading the 8B pipeline."""
    import torch
    if precision == 'bf16':
        return None
    if precision == 'int4' and int4_backend == 'dequant_bf16':
        from klein_w4a16 import smoke_test
        result = smoke_test(device='cuda')
        print(f"[int4] W4A16 checks passed (bitwise dequant mismatches: {result['dequant_bitwise_mismatches']}). "
              f"Largest DiT matmul {result['shape']}: BF16 {result['bf16_ms']:.2f} ms, "
              f"INT4 dequant+cuBLAS {result['w4a16_ms']:.2f} ms (dequant alone {result['dequant_only_ms']:.2f} ms)",
              flush=True)
        gc.collect()
        torch.cuda.empty_cache()
        return result
    # The small square kernel alone did not cover the klein x_embedder fallback path.
    for in_features, out_features in [(256, 256), (128, 3072)]:
        m = torch.nn.Sequential(torch.nn.Linear(in_features, out_features)).to(device='cuda', dtype=torch.bfloat16)
        m.eval().requires_grad_(False)
        quantize_component(m, precision, [], 'smoke_test')
        with torch.no_grad():
            y = m(torch.randn(2, in_features, device='cuda', dtype=torch.bfloat16))
            if not torch.isfinite(y).all().item():
                raise FloatingPointError('Quantized Linear smoke test produced NaN/Inf.')
        del m, y
    gc.collect()
    torch.cuda.empty_cache()
    return dict(passed=True)


def run(cfg, precision, mode_dir):
    import torch
    from diffusers import Flux2KleinPipeline

    if not torch.cuda.is_available():
        raise RuntimeError('CUDA GPU required. In Colab select an A100 GPU runtime.')
    if not torch.cuda.is_bf16_supported():
        raise RuntimeError('This experiment preserves BF16: select A100 or another BF16-capable CUDA GPU.')
    torch.cuda.set_device(0)
    torch.set_grad_enabled(False)
    torch.manual_seed(cfg['seed'])
    torch.cuda.manual_seed_all(cfg['seed'])
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True

    env = dict(python=platform.python_version(), gpu=torch.cuda.get_device_name(0),
               total_vram_gib=torch.cuda.get_device_properties(0).total_memory / 2**30,
               cuda=torch.version.cuda, compute_capability=list(torch.cuda.get_device_capability(0)),
               packages={n: metadata.version(n) for n in
                         ['torch', 'diffusers', 'transformers', 'optimum-quanto', 'accelerate', 'safetensors']})
    write_json(mode_dir / 'environment.json', env)
    print(f'[{precision}] GPU: {env["gpu"]}; package versions: {env["packages"]}', flush=True)
    int4_backend = cfg.get('int4_backend', 'quanto_tinygemm')
    kernel = kernel_label(precision, int4_backend)
    print(f'[{precision}] matmul path: {kernel}', flush=True)
    kernel_check = quantization_smoke_test(precision, int4_backend)

    torch.cuda.reset_peak_memory_stats()
    print(f'[{precision}] Loading the same model snapshot in BF16...', flush=True)
    t0 = time.perf_counter()
    pipe = Flux2KleinPipeline.from_pretrained(
        cfg['model_path'], torch_dtype=torch.bfloat16, local_files_only=True,
        low_cpu_mem_usage=True,
    ).to('cuda')
    pipe.set_progress_bar_config(disable=True)
    components = {name: getattr(pipe, name) for name in ['transformer', 'text_encoder', 'vae']}
    for model in components.values():
        model.eval().requires_grad_(False)
    if not bool(pipe.config.get('is_distilled', False)):
        raise RuntimeError('Expected the distilled klein 4B model, not klein-base-4B.')
    torch.cuda.synchronize()
    load_s = time.perf_counter() - t0
    original_params = {name: sum(p.numel() for p in model.parameters()) for name, model in components.items()}

    audits = []
    t0 = time.perf_counter()
    if precision != 'bf16':
        for component_name in cfg['quantize_components']:
            print(f'[{precision}] Quantizing {component_name} Linear weights...', flush=True)
            audits.append(quantize_component(components[component_name], precision,
                                            cfg['exclude'][component_name], component_name,
                                            int4_backend))
    torch.cuda.synchronize()
    quantize_s = time.perf_counter() - t0 if precision != 'bf16' else 0.0
    load_quant_peak_gib = torch.cuda.max_memory_allocated() / 2**30
    gc.collect()
    torch.cuda.empty_cache()

    component_info = {}
    for name, model in components.items():
        info = dict(original_parameters=original_params[name])
        try:
            info['tensor_storage_bytes'] = storage_bytes(model)
            info['tensor_storage_mib'] = info['tensor_storage_bytes'] / 2**20
        except Exception as exc:
            info['tensor_storage_bytes'] = None
            info['storage_measurement_error'] = str(exc)
        component_info[name] = info
    sizes = [x['tensor_storage_bytes'] for x in component_info.values()]
    stats = dict(precision=precision, compute_dtype='bfloat16', grad_mode='no_grad', kernel=kernel,
                 int4_backend=int4_backend if precision == 'int4' else None, kernel_check=kernel_check,
                 quantization_backend=None if precision == 'bf16' else 'optimum-quanto numerics',
                 quantize_components=cfg['quantize_components'] if precision != 'bf16' else [],
                 load_s=load_s, quantize_s=quantize_s, load_quant_peak_allocated_gib=load_quant_peak_gib,
                 resident_allocated_gib=torch.cuda.memory_allocated() / 2**30,
                 tensor_storage_mib=sum(sizes) / 2**20 if all(x is not None for x in sizes) else None,
                 components=component_info, audit=audits, scheduler_class=type(pipe.scheduler).__name__,
                 scheduler_config=dict(pipe.scheduler.config), warmup_times_s=[])
    write_json(mode_dir / 'model_stats.json', stats)

    # References were normalized once in the parent, reused byte-for-byte by every precision.
    refs = {}
    for case in cfg['cases']:
        path = case['reference_path']
        if path not in refs:
            data = Path(path).read_bytes()
            if hashlib.sha256(data).hexdigest() != case['reference_sha256']:
                raise RuntimeError('Reference file changed after experiment configuration was written.')
            with Image.open(path) as im:
                refs[path] = im.convert('RGB').copy()

    def generate(case, check_latents=False):
        step_count = 0

        def on_step(pipeline, step, timestep, callback_kwargs):
            nonlocal step_count
            step_count += 1
            if check_latents and not torch.isfinite(callback_kwargs['latents']).all().item():
                raise FloatingPointError(f'Non-finite latents at step {step}. No dtype fallback applied.')
            return callback_kwargs

        # Same CUDA generator, seed and call sequence as the original S2c implementation.
        generator = torch.Generator(device='cuda').manual_seed(case['seed'])
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
        before = torch.cuda.memory_allocated()
        t0 = time.perf_counter()
        with torch.no_grad():
            array = pipe(image=[refs[case['reference_path']]], prompt=case['prompt'],
                         width=cfg['width'], height=cfg['height'], num_inference_steps=4,
                         guidance_scale=1.0, generator=generator, max_sequence_length=512,
                         callback_on_step_end=on_step, callback_on_step_end_tensor_inputs=['latents'],
                         output_type='np').images[0]
        torch.cuda.synchronize()
        elapsed = time.perf_counter() - t0
        mem = dict(peak_allocated_gib=torch.cuda.max_memory_allocated() / 2**30,
                   peak_reserved_gib=torch.cuda.max_memory_reserved() / 2**30,
                   incremental_peak_gib=(torch.cuda.max_memory_allocated() - before) / 2**30)
        if step_count != 4:
            raise RuntimeError(f'Expected exactly 4 steps, observed {step_count}.')
        array = np.asarray(array)
        if array.shape != (cfg['height'], cfg['width'], 3) or not np.isfinite(array).all():
            raise FloatingPointError(f'Invalid image output: shape={array.shape}, NaN/Inf possible.')
        image = Image.fromarray((np.clip(array, 0, 1) * 255).round().astype(np.uint8))
        return image, elapsed, mem, step_count, float(array.std())

    print(f'[{precision}] Warm-up ({cfg["warmup_runs"]} full 4-step calls; not in benchmark)...', flush=True)
    for _ in range(cfg['warmup_runs']):
        image, seconds, _, _, _ = generate(cfg['cases'][0], check_latents=True)
        stats['warmup_times_s'].append(seconds)
        del image
    write_json(mode_dir / 'model_stats.json', stats)

    rows = []
    for ci, case in enumerate(cfg['cases']):
        for repeat in range(cfg['repeats']):
            row = dict(case_id=case['case_id'], face=case['face'], instruction=case['instruction'],
                       lang=case['lang'], prompt=case['prompt'], precision=precision, seed=case['seed'],
                       repeat=repeat, width=cfg['width'], height=cfg['height'], status='running')
            try:
                image, seconds, mem, steps, std = generate(case)
                name = f'{case["case_id"]}__{precision}__r{repeat}.png'
                image.save(mode_dir / name)  # Disk I/O is excluded from generation_e2e_s.
                row.update(status='ok', image=f'{precision}/{name}', generation_e2e_s=seconds,
                           actual_steps=steps, image_std=std, near_uniform_warning=bool(std < .005), **mem)
                print(f'[{precision}] {ci+1}/{len(cfg["cases"])} {case["case_id"]} r{repeat}: '
                      f'{seconds:.3f} s, peak {mem["peak_allocated_gib"]:.2f} GiB', flush=True)
                del image
            except Exception as exc:
                row.update(status='error', error=repr(exc), traceback=traceback.format_exc())
                print(row['traceback'], flush=True)
                rows.append(row)
                write_json(mode_dir / 'results.json', rows)
                if isinstance(exc, torch.cuda.OutOfMemoryError):
                    raise  # End this process cleanly; do not silently downscale/offload.
                continue
            rows.append(row)
            write_json(mode_dir / 'results.json', rows)
    failures = sum(x['status'] != 'ok' for x in rows)
    return dict(status='complete' if failures == 0 else 'partial', precision=precision,
                successful_images=len(rows)-failures, failed_images=failures)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True)
    parser.add_argument('--precision', choices=['bf16', 'int8', 'int4'], required=True)
    args = parser.parse_args()
    config = json.loads(Path(args.config).read_text(encoding='utf-8'))
    mode_dir = Path(config['output_dir']) / args.precision
    mode_dir.mkdir(parents=True, exist_ok=True)
    try:
        outcome = run(config, args.precision, mode_dir)
        write_json(mode_dir / 'status.json', outcome)
    except Exception as exc:
        error = traceback.format_exc()
        print(error, file=sys.stderr, flush=True)
        write_json(mode_dir / 'status.json', dict(status='failed', precision=args.precision,
                                                error=repr(exc), traceback=error))
        sys.exit(1)
