"""CPU-only comparison; imports neither torch nor any generation model."""
import html
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont, ImageOps


def read_json(path, default=None):
    return json.loads(Path(path).read_text(encoding='utf-8')) if Path(path).is_file() else default


def build_report(output_dir):
    root = Path(output_dir)
    cfg = read_json(root / 'config.json')
    identity = read_json(root / 'identity.json', {})
    rows, summary, statuses = [], [], []
    for mode in cfg['precisions']:
        mode_rows = read_json(root / mode / 'results.json', [])
        for row in mode_rows:
            row.update(identity.get(row.get('image'), {}))
        stats = read_json(root / mode / 'model_stats.json', {})
        status = read_json(root / mode / 'status.json', {'status': 'missing'})
        statuses.append(dict(precision=mode, **{k: v for k, v in status.items() if k != 'precision'}))
        rows.extend(mode_rows)
        good = [r for r in mode_rows if r['status'] == 'ok']
        summary.append(dict(precision=mode, status=status['status'], kernel=stats.get('kernel'), n_ok=len(good),
                            n_expected=len(cfg['cases']) * cfg['repeats'],
                            generation_median_s=np.median([r['generation_e2e_s'] for r in good]) if good else None,
                            peak_allocated_gib=max([r['peak_allocated_gib'] for r in good], default=None),
                            peak_reserved_gib=max([r['peak_reserved_gib'] for r in good], default=None),
                            tensor_storage_mib=stats.get('tensor_storage_mib'),
                            resident_allocated_gib=stats.get('resident_allocated_gib'),
                            load_s=stats.get('load_s'), quantize_s=stats.get('quantize_s'),
                            id_sim_mean=np.mean([r['id_sim'] for r in good if r.get('id_sim') is not None])
                            if any(r.get('id_sim') is not None for r in good) else None))
    baseline = {(r['case_id'], r['repeat']): r for r in rows if r['precision'] == 'bf16' and r['status'] == 'ok'}
    for row in rows:
        if row['status'] != 'ok':
            continue
        reference = baseline.get((row['case_id'], row['repeat']))
        if reference is None:
            continue
        a = np.asarray(Image.open(root / row['image']).convert('RGB'), dtype=np.float32) / 255
        b = np.asarray(Image.open(root / reference['image']).convert('RGB'), dtype=np.float32) / 255
        mse = float(np.mean((a-b)**2))
        row['mae_vs_bf16'] = float(np.mean(np.abs(a-b)))
        row['psnr_vs_bf16_db'] = -10 * math.log10(mse) if mse > 0 else float('inf')
        row['speedup_vs_bf16'] = reference['generation_e2e_s'] / row['generation_e2e_s']
    df, sf = pd.DataFrame(rows), pd.DataFrame(summary)
    # Speed comparison is paired by case and repeat; do not compare different surviving subsets.
    for i, mode in enumerate(cfg['precisions']):
        ratios = [r['speedup_vs_bf16'] for r in rows if r['precision'] == mode and 'speedup_vs_bf16' in r]
        sf.loc[i, 'paired_speedup_median'] = np.median(ratios) if ratios else np.nan
        sf.loc[i, 'paired_comparisons'] = len(ratios)
    df.to_csv(root / 'metrics.csv', index=False)
    sf.to_csv(root / 'summary.csv', index=False)
    (root / 'statuses.json').write_text(json.dumps(statuses, ensure_ascii=False, indent=2), encoding='utf-8')

    lookup = {(r['case_id'], r['precision']): r for r in rows if r['repeat'] == 0}
    cards = []
    for case in cfg['cases']:
        cells = [f'<figure><figcaption>Reference</figcaption><img src="inputs/{Path(case["reference_path"]).name}"></figure>']
        for mode in cfg['precisions']:
            r = lookup.get((case['case_id'], mode))
            if r and r['status'] == 'ok':
                text = f'{mode.upper()} · {r["generation_e2e_s"]:.2f} s · {r["peak_allocated_gib"]:.2f} GiB'
                if r.get('id_sim') is not None:
                    text += f' · ID {r["id_sim"]:.3f}'
                cells.append(f'<figure><figcaption>{text}</figcaption><img src="{html.escape(r["image"])}"></figure>')
            else:
                err = r.get('error', 'No successful result — see log/status.json') if r else 'No successful result — see log/status.json'
                cells.append(f'<figure><figcaption>{mode.upper()}</figcaption><pre>{html.escape(err)}</pre></figure>')
        cards.append(f'<article><h2>{html.escape(case["face"])} · {html.escape(case.get("prompt_label", case["case_id"]))}</h2>'
                     f'<p class="prompt"><b>Actual prompt:</b> {html.escape(case["prompt"])}</p>'
                     f'<div class="images">{"".join(cells)}</div></article>')
        # PNG has short English labels; full Chinese/English prompts remain legible in HTML.
        tw, th, bar = 256, 384, 48
        grid = Image.new('RGB', (tw * (1 + len(cfg['precisions'])), th + bar), 'white')
        draw = ImageDraw.Draw(grid)
        try:
            font = ImageFont.truetype('DejaVuSans.ttf', 14)
        except OSError:
            font = ImageFont.load_default()
        specs = [('REFERENCE', Path(case['reference_path']))]
        for mode in cfg['precisions']:
            r = lookup.get((case['case_id'], mode))
            specs.append((mode.upper() + (f' | {r["generation_e2e_s"]:.2f}s' if r and r['status'] == 'ok' else ' | FAILED'),
                          root / r['image'] if r and r['status'] == 'ok' else None))
        for j, (label, path) in enumerate(specs):
            draw.text((j*tw+8, 12), label, font=font, fill='black')
            if path is not None:
                with Image.open(path) as im:
                    thumb = ImageOps.contain(im.convert('RGB'), (tw, th), Image.Resampling.LANCZOS)
                grid.paste(thumb, (j*tw+(tw-thumb.width)//2, bar+(th-thumb.height)//2))
        grid.save(root / f'grid_{case["case_id"]}.png')
    int4_note = ('INT4 uses Quanto qint4 numerics, stored packed at 4 bits and dequantized to BF16 per layer for cuBLAS. '
                 if cfg.get('int4_backend', 'quanto_tinygemm') == 'dequant_bf16'
                 else 'INT4 runs through Quanto tinygemm (torch._weight_int4pack_mm). ')
    source_note = ('BF16 baseline; INT8/INT4 are integer weight-only quantization. ' + int4_note +
                   'Selected Linear layers in ' + ', '.join(cfg['quantize_components']) +
                   '; activations, VAE, embeddings/norms and excluded layers stay BF16. '
                   'Literal user prompts, with no translation or appended template. '
                   '4 steps; CFG=1; identical seeds/references/prompts; no offload/compile; no_grad for all modes. '
                   'E2E includes text encoding, image encoding, denoising and decode; excludes download/load/quantization/warm-up/file I/O. '
                   'Tensor storage includes packed data and scales, not total runtime memory. '
                   'Pixel differences measure drift from BF16, not identity or overall quality. These are CUDA timings, not phone timings.')
    page = '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
    page += '<title>Klein custom prompts quantization comparison</title><style>body{font:15px system-ui;background:#f3f5f9;color:#172033;margin:24px}article,header{background:white;padding:20px;border-radius:12px;margin-bottom:20px}.images{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}figure{margin:0}img{width:100%;height:auto}figcaption{padding:10px 0;font-weight:600}table{border-collapse:collapse;display:block;overflow:auto}th,td{padding:8px;border:1px solid #ddd}pre{white-space:pre-wrap;overflow-wrap:anywhere}.prompt{line-height:1.7;background:#eef2f8;padding:12px}</style>'
    page += f'<header><h1>FLUX.2 klein 4B · custom prompts</h1><p>{html.escape(source_note)}</p>{sf.round(3).to_html(index=False,escape=True)}'
    page += f'<details><summary>Run status / errors</summary><pre>{html.escape(json.dumps(statuses,ensure_ascii=False,indent=2))}</pre></details></header>'
    page += ''.join(cards) + '</html>'
    (root / 'report.html').write_text(page, encoding='utf-8')
    return df, sf
