"""INT4 weight storage with BF16 cuBLAS compute (W4A16: dequantize, then GEMM).

Why this exists: Quanto's qint4 path on CUDA sends every matmul through tinygemm
(torch._weight_int4pack_mm), a kernel built for batch-1 LLM decoding. Each thread block computes
only a 16x8 output tile, so with ~8k tokens per call the weights are re-read and re-dequantized
hundreds of times and the linear layers ran ~12x slower than cuBLAS.

What this does instead: weights stay packed at 4 bits (same bytes per parameter as Quanto's int4).
In every forward pass one layer is expanded to BF16 with three elementwise kernels and the matmul
goes to the normal cuBLAS kernel through F.linear.

Numerics: the int4 codes, scales and shifts come from optimum-quanto 0.2.7's own MaxOptimizer and
quantize_affine, so they are bit-identical to Quanto's qint4. For group-128 layers the BF16 weight
is rebuilt with the arithmetic tinygemm applies on CUDA, bf16(fma(q - 8, scale, zero)) with
Quanto's zero = bf16(8 * scale - shift). Layers Quanto keeps on its generic path (in_features <= 128,
e.g. the DiT x_embedder) use Quanto's generic formula bf16(bf16(scale * q) - shift).
"""
import fnmatch
import time

import torch
import torch.nn.functional as F

BACKEND = 'dequant_bf16'
KERNEL_NAME = 'W4 storage -> BF16 dequant + cuBLAS'


def quanto_group_size(in_features):
    """Group-size rule of optimum.quanto QModuleMixin (0.2.7) for qint4 weights; None = per row."""
    group_size = 128
    if in_features > group_size:
        while in_features % group_size != 0 and group_size > 32:
            group_size -= 32
        if in_features % group_size == 0:
            return group_size
    return None


class W4A16Linear(torch.nn.Module):
    """Drop-in replacement for a BF16 nn.Linear: 4-bit packed weight, BF16 compute."""

    def __init__(self, linear):
        super().__init__()
        from optimum.quanto import MaxOptimizer, qint4

        w = linear.weight.detach()
        if w.dtype != torch.bfloat16 or w.dim() != 2:
            raise TypeError(f'W4A16Linear expects a 2-D bfloat16 weight, got {w.dtype} {tuple(w.shape)}')
        n, k = w.shape
        group_size = quanto_group_size(k)
        g = k if group_size is None else group_size
        if g % 2:
            raise ValueError(f'in_features={k}: a group of {g} values cannot be packed two per byte')
        self.in_features, self.out_features, self.group_size = k, n, g
        # Quanto picks tinygemm for qint4 + bf16 + group 128 on sm80+; everything else is dequantized generically.
        self.tinygemm_formula = group_size == 128

        scale, shift = MaxOptimizer()(w, qtype=qint4, axis=0, group_size=group_size)
        q = torch.ops.quanto.quantize_affine(w, bits=4, axis=0, group_size=group_size, scale=scale, shift=shift)
        groups = k // g
        q = q.reshape(n, groups, 2, g // 2)            # [row, group, half of group, position]
        scale = scale.reshape(n, groups, 1, 1)
        shift = shift.reshape(n, groups, 1, 1)
        if self.tinygemm_formula:
            codes = q ^ 8                               # 4-bit two's complement of q - 8
            zero = (-shift) + 2 ** (qint4.bits - 1) * scale   # Quanto's tinygemm zero, same bf16 op order
            nibble_shifts = torch.tensor([4, 0], dtype=torch.int8, device=w.device)
        else:
            codes = q
            zero = shift
            nibble_shifts = torch.tensor([0, 4], dtype=torch.uint8, device=w.device)
        # One byte holds element j (low nibble) and element j + g/2 (high nibble) of the same group.
        self.register_buffer('packed', ((codes[:, :, 1] << 4) | codes[:, :, 0]).contiguous())
        self.register_buffer('scale', scale.contiguous())
        self.register_buffer('zero', zero.contiguous())
        self.register_buffer('nibble_shifts', nibble_shifts.view(1, 1, 2, 1), persistent=False)
        if linear.bias is not None:
            self.bias = torch.nn.Parameter(linear.bias.detach(), requires_grad=False)
        else:
            self.register_parameter('bias', None)
        self.train(linear.training)

    def dequantize(self):
        if self.tinygemm_formula:
            t = torch.bitwise_left_shift(self.packed.view(torch.int8).unsqueeze(2), self.nibble_shifts)
            t.bitwise_right_shift_(4)                   # arithmetic shift: signed q - 8 in [-8, 7]
            w = torch.addcmul(self.zero, t, self.scale) # fp32 math, one rounding to bf16 (= tinygemm __hfma2)
        else:
            t = torch.bitwise_right_shift(self.packed.unsqueeze(2), self.nibble_shifts)
            t.bitwise_and_(15)
            w = self.scale * t                          # Quanto generic: bf16(scale * q) ...
            w.sub_(self.zero)                           # ... then bf16(. - shift)
        return w.view(self.out_features, self.in_features)

    def forward(self, x):
        return F.linear(x, self.dequantize(), self.bias)

    # ---- validation helpers (slow, independent of the fast path) ----
    @torch.no_grad()
    def unpacked_codes(self):
        """The Quanto int4 codes q in [0, 15], shape [out, in]."""
        p = self.packed.to(torch.int32)
        codes = torch.stack((p & 15, p >> 4), dim=2)
        if self.tinygemm_formula:
            codes = codes ^ 8
        return codes.reshape(self.out_features, self.in_features).to(torch.uint8)

    @torch.no_grad()
    def reference_dequantize(self):
        q = self.unpacked_codes().reshape(self.packed.shape[0], self.packed.shape[1], 2, -1).float()
        if self.tinygemm_formula:
            w = ((q - 8) * self.scale.float() + self.zero.float()).to(torch.bfloat16)
        else:
            w = (q * self.scale.float()).to(torch.bfloat16)
            w = (w.float() - self.zero.float()).to(torch.bfloat16)
        return w.reshape(self.out_features, self.in_features)

    def extra_repr(self):
        formula = 'tinygemm' if self.tinygemm_formula else 'quanto-generic'
        return (f'in_features={self.in_features}, out_features={self.out_features}, '
                f'group_size={self.group_size}, formula={formula}, bias={self.bias is not None}')


def quantize_module_w4a16(model, exclude, component_name):
    """Replace every nn.Linear not matching `exclude` with W4A16Linear; fail loudly on any leftover."""
    targets = [name for name, m in model.named_modules()
               if isinstance(m, torch.nn.Linear) and not any(fnmatch.fnmatchcase(name, p) for p in exclude)]
    if not targets:
        raise RuntimeError(f'{component_name}: no Linear layers selected; refusing an unquantized result.')
    elements = 0
    for name in targets:
        parent_name, _, child = name.rpartition('.')
        parent = model.get_submodule(parent_name) if parent_name else model
        linear = getattr(parent, child)
        elements += linear.weight.numel()
        setattr(parent, child, W4A16Linear(linear))
        del linear
    actual = {name: m for name, m in model.named_modules() if isinstance(m, W4A16Linear)}
    if set(actual) != set(targets):
        raise RuntimeError(f'{component_name}: requested {len(targets)} layers, converted {len(actual)}.')
    leftover = [n for n, m in model.named_modules() if n in set(targets) and type(m) is torch.nn.Linear]
    if leftover:
        raise RuntimeError(f'{component_name}: still BF16 after conversion: {leftover[:5]}')
    layer_map, formulas = {}, {'tinygemm': 0, 'quanto-generic': 0}
    for name, m in actual.items():
        if m.packed.dtype != torch.uint8 or m.packed.numel() * 2 != m.in_features * m.out_features:
            raise RuntimeError(f'{component_name}.{name}: packed weight has the wrong size or dtype.')
        if hasattr(m, 'weight'):
            raise RuntimeError(f'{component_name}.{name}: a full-precision weight is still attached.')
        formula = 'tinygemm' if m.tinygemm_formula else 'quanto-generic'
        formulas[formula] += 1
        layer_map[name] = dict(weights='qint4', group_size=m.group_size, dequant_formula=formula)
    return dict(component=component_name, backend=BACKEND, kernel=KERNEL_NAME,
                quantized_linear_layers=len(actual), quantized_weight_elements=elements,
                excluded_patterns=exclude, dequant_formulas=formulas, quantization_map=layer_map)


@torch.no_grad()
def smoke_test(device='cuda', benchmark_shape=(8064, 3072, 27648)):
    """Exactness checks on small layers, then a speed check on the largest DiT matmul shape."""
    from optimum.quanto import MaxOptimizer, qint4

    torch.manual_seed(0)
    mismatches = 0
    for k, n in ((256, 256), (128, 3072), (3072, 640)):
        linear = torch.nn.Linear(k, n, bias=False).to(device=device, dtype=torch.bfloat16)
        w0 = linear.weight.detach().clone()
        qmod = W4A16Linear(linear)
        gs = quanto_group_size(k)
        scale, shift = MaxOptimizer()(w0, qtype=qint4, axis=0, group_size=gs)
        q_ref = torch.ops.quanto.quantize_affine(w0, bits=4, axis=0, group_size=gs, scale=scale, shift=shift)
        if not torch.equal(qmod.unpacked_codes(), q_ref.reshape(n, k)):
            raise RuntimeError(f'W4A16 smoke test {k}->{n}: packed codes differ from Quanto quantize_affine.')
        w = qmod.dequantize()
        ref = qmod.reference_dequantize()
        diff = (w.float() - ref.float()).abs()
        if (diff > ref.float().abs() * 2 ** -7).any().item():   # more than ~1 bf16 ulp means a real bug
            raise RuntimeError(f'W4A16 smoke test {k}->{n}: fast dequantization disagrees with the reference.')
        mismatches += int((diff > 0).sum().item())
        rel = ((w.float() - w0.float()).norm() / w0.float().norm()).item()
        if not rel < 0.2:
            raise RuntimeError(f'W4A16 smoke test {k}->{n}: relative weight error {rel:.3f} is too large.')
        x = torch.randn(37, k, device=device, dtype=torch.bfloat16)
        y = qmod(x).float()
        y_ref = F.linear(x, w).float()
        if not torch.isfinite(y).all().item() or (y - y_ref).abs().max().item() > 1e-2 * y_ref.abs().max().item():
            raise RuntimeError(f'W4A16 smoke test {k}->{n}: forward does not match F.linear on the dequantized weight.')
        del linear, qmod, w0, w, ref, x, y, y_ref
    result = dict(checks='codes == Quanto quantize_affine; dequant == reference; forward == F.linear',
                  passed=True, dequant_bitwise_mismatches=mismatches)
    if device == 'cuda' and benchmark_shape:
        m, k, n = benchmark_shape
        x = torch.randn(m, k, device=device, dtype=torch.bfloat16)
        linear = torch.nn.Linear(k, n, bias=False).to(device=device, dtype=torch.bfloat16)

        def bench(fn, iters=10):
            for _ in range(3):
                fn()
            torch.cuda.synchronize()
            start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
            start.record()
            for _ in range(iters):
                fn()
            end.record()
            torch.cuda.synchronize()
            return start.elapsed_time(end) / iters

        bf16_ms = bench(lambda: linear(x))
        qmod = W4A16Linear(linear)
        del linear
        w4_ms = bench(lambda: qmod(x))
        deq_ms = bench(qmod.dequantize)
        result.update(shape=[m, k, n], bf16_ms=bf16_ms, w4a16_ms=w4_ms, dequant_only_ms=deq_ms,
                      slowdown_vs_bf16=w4_ms / bf16_ms)
        del x, qmod
        torch.cuda.empty_cache()
    return result
